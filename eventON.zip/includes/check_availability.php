<?php

// Obtenemos la información de la ubicación de la reunión
$location_name = $_POST['location_name'];

var_dump($location_name);

// Comprobamos si el usuario ha seleccionado una ubicacion
if ($location_name) {
    // Obtenemos el ID de la ubicación
    $location_obj = EventON::get_location_by_name($location_name);

    // Si el ID de la ubicación es válido
    if ($location_obj) {
        $location_id = $location_obj->ID;
    } else {
        // La ubicación no existe
        $location_id = null;
    }
} else {
    // El usuario no ha seleccionado una ubicacion
    // No permitimos que se publique el evento
    echo '<div class="error">Debe seleccionar una ubicacion para la reunion.</div>';
    return;
}

// Obtenemos una lista de todos los eventos publicados
$events = EventON::get_events(array(
    'status' => 'published',
    'location' => $location_id,
));

// Filtramos la lista de eventos para que solo incluya eventos que se celebren en la misma fecha y hora que la reunión que el usuario está creando
$events = array_filter($events, function($event) {
    return $event->start_date == $start_date && $event->start_time == $start_time;
});

// Si hay algún evento en la lista, mostramos un mensaje de error
if (!empty($events)) {
    // Comprobamos si el evento publicado tiene la misma ubicacion que la reunion
    foreach ($events as $event) {
        if ($event->location_id == $location_id) {
            // Si es la misma ubicacion, mostramos el mensaje de error
            echo '<div class="error">Ya hay una reunion programada para esta fecha y hora. Por favor, elija otra fecha y hora.</div>';
            return;
        }
    }
}

// Si no hay eventos publicados con la misma ubicacion, continuamos con el proceso de creacion de la reunion
