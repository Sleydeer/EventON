<?php
/**
 * Email Footer
 *
 * @author 		EventON
 * @package 	EventON/Templates/Emails
 * @version     0.1
 *  
 * To customize copy this file to your theme folder in below folder structure
 * path: your-theme-dir/eventon/templates/email/
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

		</div>
    </div>
</body>
</html>